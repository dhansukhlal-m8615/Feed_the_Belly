package com.example.foodrescue;

public class PayPalConfig {

    public static final String PAYPAL_CLIENT_ID = "AV2hu3Dqb0oxuPotK83QGw40Sfl1nikzTsUfOPXB2d6uRhlSgZHVh_cKqVHbxmD4jlT_VSGk0H57Jl2H";

}
