# Aakash145-W21G6_FeedTheBelly
Android app for free Food Service
Use CSV files to upload the dishes as a restaurant
Use Valid address as google api works on address
Paypal works on any user login details as we use
